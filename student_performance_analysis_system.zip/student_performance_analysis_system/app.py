import os
from pathlib import Path

import mysql.connector
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from mysql.connector import IntegrityError

load_dotenv()
app = Flask(__name__)

DB_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "localhost"),
    "port": int(os.getenv("MYSQL_PORT", "3306")),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "database": os.getenv("MYSQL_DATABASE", "student_performance_db"),
}
LOW_THRESHOLD = float(os.getenv("LOW_PERFORMANCE_THRESHOLD", "40"))
CHART_DIR = Path(os.getenv("CHART_OUTPUT_DIR", "reports/charts"))
if not CHART_DIR.is_absolute():
    CHART_DIR = Path(__file__).resolve().parent / CHART_DIR
CHART_DIR.mkdir(parents=True, exist_ok=True)


def connection():
    """Create a fresh MySQL connection for one request."""
    return mysql.connector.connect(**DB_CONFIG)


def query_all(sql, params=()):
    conn = connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(sql, params)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()


def query_one(sql, params=()):
    rows = query_all(sql, params)
    return rows[0] if rows else None


def change(sql, params=()):
    conn = connection()
    cursor = conn.cursor()
    try:
        cursor.execute(sql, params)
        conn.commit()
        return cursor.lastrowid, cursor.rowcount
    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()
        conn.close()


def fail(message, status=400):
    return jsonify({"error": message}), status


def body():
    return request.get_json(silent=True) or {}


def text_field(data, key, max_len):
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{key} is required and must be text.")
    value = value.strip()
    if len(value) > max_len:
        raise ValueError(f"{key} must be at most {max_len} characters.")
    return value


def number_field(data, key, default=None):
    value = data.get(key, default)
    if value is None or value == "":
        raise ValueError(f"{key} is required and must be numeric.")
    try:
        return float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{key} must be numeric.")


def marks_df():
    rows = query_all("""
        SELECT s.student_id, s.roll_no, s.name, s.section,
               sub.subject_id, sub.subject_name, sub.max_marks, sub.pass_marks,
               m.mark_id, m.assessment, m.marks_obtained
        FROM marks m
        JOIN students s ON s.student_id=m.student_id
        JOIN subjects sub ON sub.subject_id=m.subject_id
        ORDER BY s.roll_no, sub.subject_name, m.assessment
    """)
    return pd.DataFrame(rows)


def grade(p):
    if p >= 90: return "A+"
    if p >= 80: return "A"
    if p >= 70: return "B"
    if p >= 60: return "C"
    if p >= 50: return "D"
    if p >= 40: return "E"
    return "F"


@app.get("/")
def home():
    return jsonify({
        "message": "Student Performance Analysis System API",
        "status": "running",
        "routes": [
            "GET/POST /api/students", "GET/PUT/DELETE /api/students/<id>",
            "GET/POST /api/subjects", "GET/PUT/DELETE /api/subjects/<id>",
            "GET/POST /api/marks", "PUT/DELETE /api/marks/<id>",
            "GET /api/reports/summary", "GET /api/reports/student/<id>",
            "GET /api/reports/subjects", "GET /api/reports/classes",
            "GET /api/reports/toppers?limit=10",
            "GET /api/reports/low-performers?threshold=40",
            "POST /api/reports/charts", "GET /api/reports/charts/<filename>"
        ]
    })


# -------------------- STUDENT CRUD --------------------
@app.get("/api/students")
def students_list():
    section = request.args.get("section")
    if section:
        return jsonify(query_all("SELECT * FROM students WHERE section=%s ORDER BY roll_no", (section,)))
    return jsonify(query_all("SELECT * FROM students ORDER BY roll_no"))


@app.get("/api/students/<int:sid>")
def student_get(sid):
    row = query_one("SELECT * FROM students WHERE student_id=%s", (sid,))
    return jsonify(row) if row else fail("Student not found.", 404)


@app.post("/api/students")
def student_create():
    data = body()
    try:
        values = (text_field(data, "roll_no", 30), text_field(data, "name", 100),
                  text_field(data, "section", 20))
        new_id, _ = change("INSERT INTO students (roll_no,name,section) VALUES (%s,%s,%s)", values)
        return jsonify({"message": "Student created.", "student_id": new_id}), 201
    except ValueError as exc:
        return fail(str(exc))
    except IntegrityError:
        return fail("That roll number already exists.", 409)


@app.put("/api/students/<int:sid>")
def student_update(sid):
    if not query_one("SELECT student_id FROM students WHERE student_id=%s", (sid,)):
        return fail("Student not found.", 404)
    data = body()
    try:
        values = (text_field(data, "roll_no", 30), text_field(data, "name", 100),
                  text_field(data, "section", 20), sid)
        change("UPDATE students SET roll_no=%s,name=%s,section=%s WHERE student_id=%s", values)
        return jsonify({"message": "Student updated."})
    except ValueError as exc:
        return fail(str(exc))
    except IntegrityError:
        return fail("That roll number is already in use.", 409)


@app.delete("/api/students/<int:sid>")
def student_delete(sid):
    _, count = change("DELETE FROM students WHERE student_id=%s", (sid,))
    return jsonify({"message": "Student deleted."}) if count else fail("Student not found.", 404)


# -------------------- SUBJECT CRUD --------------------
@app.get("/api/subjects")
def subjects_list():
    return jsonify(query_all("SELECT * FROM subjects ORDER BY subject_name"))


@app.get("/api/subjects/<int:subid>")
def subject_get(subid):
    row = query_one("SELECT * FROM subjects WHERE subject_id=%s", (subid,))
    return jsonify(row) if row else fail("Subject not found.", 404)


@app.post("/api/subjects")
def subject_create():
    data = body()
    try:
        name = text_field(data, "subject_name", 100)
        maximum = number_field(data, "max_marks", 100)
        passing = number_field(data, "pass_marks", 40)
        if maximum <= 0 or passing < 0 or passing > maximum:
            return fail("max_marks must be > 0 and pass_marks must be between 0 and max_marks.")
        new_id, _ = change("INSERT INTO subjects (subject_name,max_marks,pass_marks) VALUES (%s,%s,%s)",
                           (name, maximum, passing))
        return jsonify({"message": "Subject created.", "subject_id": new_id}), 201
    except ValueError as exc:
        return fail(str(exc))
    except IntegrityError:
        return fail("That subject name already exists.", 409)


@app.put("/api/subjects/<int:subid>")
def subject_update(subid):
    if not query_one("SELECT subject_id FROM subjects WHERE subject_id=%s", (subid,)):
        return fail("Subject not found.", 404)
    data = body()
    try:
        name = text_field(data, "subject_name", 100)
        maximum = number_field(data, "max_marks", 100)
        passing = number_field(data, "pass_marks", 40)
        if maximum <= 0 or passing < 0 or passing > maximum:
            return fail("max_marks must be > 0 and pass_marks must be between 0 and max_marks.")
        change("UPDATE subjects SET subject_name=%s,max_marks=%s,pass_marks=%s WHERE subject_id=%s",
               (name, maximum, passing, subid))
        return jsonify({"message": "Subject updated."})
    except ValueError as exc:
        return fail(str(exc))
    except IntegrityError:
        return fail("That subject name already exists.", 409)


@app.delete("/api/subjects/<int:subid>")
def subject_delete(subid):
    _, count = change("DELETE FROM subjects WHERE subject_id=%s", (subid,))
    return jsonify({"message": "Subject deleted."}) if count else fail("Subject not found.", 404)


# -------------------- MARKS CRUD --------------------
@app.get("/api/marks")
def marks_list():
    return jsonify(query_all("""
        SELECT m.mark_id,m.student_id,s.roll_no,s.name AS student_name,s.section,
               m.subject_id,sub.subject_name,sub.max_marks,sub.pass_marks,
               m.assessment,m.marks_obtained
        FROM marks m JOIN students s ON s.student_id=m.student_id
        JOIN subjects sub ON sub.subject_id=m.subject_id
        ORDER BY s.roll_no,sub.subject_name,m.assessment
    """))


def validate_mark_payload(data):
    try:
        sid, subid = int(data["student_id"]), int(data["subject_id"])
        score = number_field(data, "marks_obtained")
    except (KeyError, TypeError, ValueError):
        raise ValueError("Provide integer student_id, integer subject_id, and numeric marks_obtained.")
    assessment = str(data.get("assessment", "Final")).strip()
    if not assessment or len(assessment) > 50:
        raise ValueError("assessment must contain 1–50 characters.")
    if not query_one("SELECT student_id FROM students WHERE student_id=%s", (sid,)):
        raise LookupError("Student not found.")
    subject = query_one("SELECT max_marks FROM subjects WHERE subject_id=%s", (subid,))
    if not subject:
        raise LookupError("Subject not found.")
    if score < 0 or score > float(subject["max_marks"]):
        raise ValueError(f"marks_obtained must be between 0 and {subject['max_marks']}.")
    return sid, subid, assessment, score


@app.post("/api/marks")
def mark_create():
    try:
        values = validate_mark_payload(body())
        new_id, _ = change("INSERT INTO marks (student_id,subject_id,assessment,marks_obtained) VALUES (%s,%s,%s,%s)", values)
        return jsonify({"message": "Marks recorded.", "mark_id": new_id}), 201
    except ValueError as exc:
        return fail(str(exc))
    except LookupError as exc:
        return fail(str(exc), 404)
    except IntegrityError:
        return fail("Marks for this student, subject and assessment already exist.", 409)


@app.put("/api/marks/<int:mid>")
def mark_update(mid):
    if not query_one("SELECT mark_id FROM marks WHERE mark_id=%s", (mid,)):
        return fail("Mark record not found.", 404)
    try:
        values = validate_mark_payload(body())
        change("UPDATE marks SET student_id=%s,subject_id=%s,assessment=%s,marks_obtained=%s WHERE mark_id=%s",
               values + (mid,))
        return jsonify({"message": "Marks updated."})
    except ValueError as exc:
        return fail(str(exc))
    except LookupError as exc:
        return fail(str(exc), 404)
    except IntegrityError:
        return fail("Marks for this student, subject and assessment already exist.", 409)


@app.delete("/api/marks/<int:mid>")
def mark_delete(mid):
    _, count = change("DELETE FROM marks WHERE mark_id=%s", (mid,))
    return jsonify({"message": "Marks deleted."}) if count else fail("Mark record not found.", 404)


# -------------------- REPORTS AND DATA ANALYSIS --------------------
@app.get("/api/reports/summary")
def report_summary():
    df = marks_df()
    if df.empty:
        return jsonify({"students_with_marks": 0, "subjects_with_marks": 0,
                        "average_percentage": 0, "median_percentage": 0,
                        "minimum_percentage": 0, "maximum_percentage": 0})
    pct = df["marks_obtained"].astype(float) / df["max_marks"].astype(float) * 100
    values = pct.to_numpy(dtype=float)
    return jsonify({
        "students_with_marks": int(df["student_id"].nunique()),
        "subjects_with_marks": int(df["subject_id"].nunique()),
        "average_percentage": round(float(np.mean(values)), 2),
        "median_percentage": round(float(np.median(values)), 2),
        "minimum_percentage": round(float(np.min(values)), 2),
        "maximum_percentage": round(float(np.max(values)), 2)
    })


@app.get("/api/reports/student/<int:sid>")
def report_student(sid):
    if not query_one("SELECT student_id FROM students WHERE student_id=%s", (sid,)):
        return fail("Student not found.", 404)
    df = marks_df()
    if df.empty:
        return fail("No marks are recorded for this student.", 404)
    df = df[df["student_id"] == sid].copy()
    if df.empty:
        return fail("No marks are recorded for this student.", 404)
    df["marks_obtained"] = df["marks_obtained"].astype(float)
    df["max_marks"] = df["max_marks"].astype(float)
    df["pass_marks"] = df["pass_marks"].astype(float)
    df["percentage"] = df["marks_obtained"] / df["max_marks"] * 100
    df["status"] = np.where(df["marks_obtained"] >= df["pass_marks"], "Pass", "Fail")
    obtained, maximum = float(df["marks_obtained"].sum()), float(df["max_marks"].sum())
    percentage = obtained / maximum * 100 if maximum else 0
    subjects = df[["subject_name", "assessment", "marks_obtained", "max_marks",
                   "pass_marks", "percentage", "status"]].to_dict(orient="records")
    return jsonify({
        "student_id": sid, "roll_no": str(df.iloc[0]["roll_no"]),
        "name": str(df.iloc[0]["name"]), "section": str(df.iloc[0]["section"]),
        "subjects": subjects, "total_obtained": round(obtained, 2),
        "total_maximum": round(maximum, 2), "percentage": round(percentage, 2),
        "average_subject_percentage": round(float(df["percentage"].mean()), 2),
        "grade": grade(percentage),
        "overall_status": "Pass" if (df["status"] == "Fail").sum() == 0 else "Fail"
    })


@app.get("/api/reports/subjects")
def report_subjects():
    df = marks_df()
    if df.empty:
        return jsonify([])
    df["marks_obtained"] = df["marks_obtained"].astype(float)
    df["max_marks"] = df["max_marks"].astype(float)
    df["pass_marks"] = df["pass_marks"].astype(float)
    df["percentage"] = df["marks_obtained"] / df["max_marks"] * 100
    df["passed"] = df["marks_obtained"] >= df["pass_marks"]
    grouped = df.groupby("subject_name").agg(
        records=("marks_obtained", "count"),
        average_marks=("marks_obtained", "mean"),
        median_marks=("marks_obtained", "median"),
        minimum_marks=("marks_obtained", "min"),
        maximum_marks=("marks_obtained", "max"),
        pass_percentage=("passed", lambda x: x.mean() * 100)
    ).reset_index()
    numeric = ["average_marks", "median_marks", "minimum_marks", "maximum_marks", "pass_percentage"]
    grouped[numeric] = grouped[numeric].round(2)
    return jsonify(grouped.to_dict(orient="records"))


@app.get("/api/reports/classes")
def report_classes():
    df = marks_df()
    if df.empty:
        return jsonify([])
    df["percentage"] = df["marks_obtained"].astype(float) / df["max_marks"].astype(float) * 100
    grouped = df.groupby("section").agg(
        students_with_marks=("student_id", "nunique"),
        average_percentage=("percentage", "mean"),
        mark_records=("mark_id", "count")
    ).reset_index()
    grouped["average_percentage"] = grouped["average_percentage"].round(2)
    return jsonify(grouped.to_dict(orient="records"))


@app.get("/api/reports/toppers")
def report_toppers():
    try:
        limit = int(request.args.get("limit", "10"))
        if limit < 1 or limit > 100:
            return fail("limit must be between 1 and 100.")
    except ValueError:
        return fail("limit must be an integer.")
    df = marks_df()
    if df.empty:
        return jsonify([])
    df["obtained"] = df["marks_obtained"].astype(float)
    df["maximum"] = df["max_marks"].astype(float)
    grouped = df.groupby(["student_id", "roll_no", "name", "section"], as_index=False).agg(
        total_obtained=("obtained", "sum"), total_maximum=("maximum", "sum"))
    grouped["percentage"] = (grouped["total_obtained"] / grouped["total_maximum"] * 100).round(2)
    grouped = grouped.sort_values(["percentage", "name"], ascending=[False, True]).head(limit)
    return jsonify(grouped.to_dict(orient="records"))


@app.get("/api/reports/low-performers")
def report_low_performers():
    try:
        threshold = float(request.args.get("threshold", str(LOW_THRESHOLD)))
        if threshold < 0 or threshold > 100:
            return fail("threshold must be between 0 and 100.")
    except ValueError:
        return fail("threshold must be numeric.")
    df = marks_df()
    if df.empty:
        return jsonify({"threshold_percentage": threshold, "students": []})
    df["percentage"] = df["marks_obtained"].astype(float) / df["max_marks"].astype(float) * 100
    low = df[df["percentage"] < threshold]
    records = low[["student_id", "roll_no", "name", "section", "subject_name", "percentage"]].copy()
    records["percentage"] = records["percentage"].round(2)
    return jsonify({"threshold_percentage": threshold, "students": records.to_dict(orient="records")})


@app.post("/api/reports/charts")
def report_charts():
    df = marks_df()
    if df.empty:
        return fail("No marks are available yet. Add marks before generating charts.", 400)
    df["marks_obtained"] = df["marks_obtained"].astype(float)
    df["max_marks"] = df["max_marks"].astype(float)
    df["pass_marks"] = df["pass_marks"].astype(float)
    df["percentage"] = df["marks_obtained"] / df["max_marks"] * 100
    df["passed"] = df["marks_obtained"] >= df["pass_marks"]

    averages = df.groupby("subject_name")["percentage"].mean().sort_values(ascending=False)
    plt.figure(figsize=(9, 5))
    averages.plot(kind="bar")
    plt.title("Average Percentage by Subject")
    plt.xlabel("Subject")
    plt.ylabel("Average percentage (%)")
    plt.ylim(0, 100)
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "subject_averages.png", dpi=150)
    plt.close()

    passes = df.groupby("subject_name")["passed"].mean().mul(100)
    plt.figure(figsize=(9, 5))
    passes.plot(kind="bar")
    plt.title("Pass Percentage by Subject")
    plt.xlabel("Subject")
    plt.ylabel("Students passing (%)")
    plt.ylim(0, 100)
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "pass_percentages.png", dpi=150)
    plt.close()

    return jsonify({
        "message": "Charts generated from stored MySQL data.",
        "charts": {
            "subject_averages": "/api/reports/charts/subject_averages.png",
            "pass_percentages": "/api/reports/charts/pass_percentages.png"
        }
    })


@app.get("/api/reports/charts/<path:filename>")
def chart_file(filename):
    if filename not in {"subject_averages.png", "pass_percentages.png"}:
        return fail("Chart not found.", 404)
    return send_from_directory(CHART_DIR, filename)


@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Not Found", "message": "The requested API route does not exist."}), 404


@app.errorhandler(Exception)
def unexpected_error(exc):
    app.logger.exception("Unhandled error: %s", exc)
    return jsonify({"error": "Internal Server Error",
                    "message": "Check the application terminal for details."}), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000,
            debug=os.getenv("FLASK_DEBUG", "False").lower() == "true")
