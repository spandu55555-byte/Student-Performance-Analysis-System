# Student Performance Analysis System

A beginner-friendly Flask REST API using MySQL, Pandas, NumPy, and Matplotlib. The project supports student/subject/marks CRUD, reports, topper and low-performer lists, and chart generation.

## Folder structure

```text
student_performance_analysis_system/
├── app.py
├── schema.sql
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── reports/
    └── charts/
        └── .gitkeep
```

## Requirements
- Python 3.10+
- MySQL Server 8+
- Postman or VS Code Thunder Client (optional)

## Run on Windows

1. Start MySQL Server.
2. Open MySQL Workbench and run all of `schema.sql`, or use:
   `mysql -u root -p < schema.sql`
3. Open a terminal in this project folder.
4. Create and activate a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt:
   `.venv\Scripts\activate.bat`

5. Install packages:

   ```bash
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

6. Copy `.env.example` to `.env`:

   PowerShell: `Copy-Item .env.example .env`
   Command Prompt: `copy .env.example .env`

7. Edit `.env` and enter your MySQL username and password. Never commit `.env`.
8. Start the server:

   ```bash
   python app.py
   ```

9. Open `http://127.0.0.1:5000/`. It should return a JSON welcome message and route list.

## API endpoints

Base URL: `http://127.0.0.1:5000`

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | List students |
| GET | `/api/students?section=A` | Filter students by section |
| GET | `/api/students/1` | Get student |
| POST | `/api/students` | Add student |
| PUT | `/api/students/1` | Update student |
| DELETE | `/api/students/1` | Delete student and their marks |
| GET | `/api/subjects` | List subjects |
| POST | `/api/subjects` | Add subject |
| PUT | `/api/subjects/1` | Update subject |
| DELETE | `/api/subjects/1` | Delete subject and its marks |
| GET | `/api/marks` | List marks |
| POST | `/api/marks` | Add marks |
| PUT | `/api/marks/1` | Update marks |
| DELETE | `/api/marks/1` | Delete marks |
| GET | `/api/reports/summary` | Mean, median, min/max percentage |
| GET | `/api/reports/student/1` | Student total, percentage, grade, pass/fail |
| GET | `/api/reports/subjects` | Subject-wise statistics and pass rate |
| GET | `/api/reports/classes` | Section-wise summary |
| GET | `/api/reports/toppers?limit=10` | Top students |
| GET | `/api/reports/low-performers?threshold=40` | Mark records below threshold |
| POST | `/api/reports/charts` | Generate charts |
| GET | `/api/reports/charts/subject_averages.png` | View subject average chart |
| GET | `/api/reports/charts/pass_percentages.png` | View pass percentage chart |

## Sample requests (Postman)

Choose **Body → raw → JSON** for POST/PUT requests.

Create a student:
```json
{"roll_no":"CSE001","name":"Ananya Rao","section":"A"}
```

Create a subject:
```json
{"subject_name":"Python","max_marks":100,"pass_marks":40}
```

Create marks using the IDs returned by those requests:
```json
{"student_id":1,"subject_id":1,"assessment":"Midterm","marks_obtained":78}
```

Then try `GET /api/reports/student/1`, `GET /api/reports/subjects`, and `GET /api/reports/toppers`. Send a POST request to `/api/reports/charts`, then open the two chart URLs.

## Calculation rules

- Subject percentage = marks obtained / maximum marks × 100.
- Subject pass/fail uses that subject's configured `pass_marks`.
- Overall percentage = total obtained / total maximum for recorded mark rows × 100.
- Overall status is Pass only when every recorded mark row meets its subject pass mark.
- Grades: A+ ≥90, A ≥80, B ≥70, C ≥60, D ≥50, E ≥40, F <40.
- Low-performer records have a percentage below the selected threshold (40 by default).
- Multiple assessments for one subject are currently counted as separate rows. For a production system, decide whether to report the latest assessment, weighted assessments, or final assessment only.

## Validation and database design

- MySQL primary keys and foreign keys preserve relationships.
- Roll numbers and subject names are unique.
- SQL uses parameterized queries.
- Marks outside 0 to the subject's maximum are rejected.
- `.env` holds local database credentials and is excluded from Git.

## Common errors

- `ModuleNotFoundError`: activate `.venv`, then install `requirements.txt`.
- `Access denied`: check username/password in `.env`.
- `Unknown database`: run `schema.sql`.
- MySQL connection refused: start MySQL and check host/port.
- Port 5000 is busy: close the other process using it before restarting.

## Push to GitHub

1. Create an empty repository on GitHub. Do not add a README there if you already have this local README.
2. Open terminal in this project directory and run:

   ```bash
   git init
   git add .
   git status
   git commit -m "Initial commit: Student Performance Analysis System"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/student-performance-analysis-system.git
   git push -u origin main
   ```

3. Replace `YOUR-USERNAME` with your GitHub username and use your actual repository URL.
4. If Git reports `remote origin already exists`, run:
   `git remote set-url origin https://github.com/YOUR-USERNAME/student-performance-analysis-system.git`
5. Complete GitHub's browser authentication if prompted. Do not push `.env`, passwords, or database credentials.
